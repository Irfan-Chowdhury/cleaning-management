<aside class="dashboard-sidebar" aria-label="Dashboard navigation">
    <div class="sidebar-logo">
        <a href="#" class="sidebar-logo-link" aria-label="Cleaning Management">
            
            <img id="sidebar-company-logo" src="<?php echo e($sidebarSettings?->company_logo_url ?? asset('public/assets/images/company_logo/brand_logo.png')); ?>" alt="Cleaning Management logo">
        </a>

        <button type="button" class="sidebar-close" aria-label="Close sidebar">
            <i class="fas fa-times" aria-hidden="true"></i>
        </button>
    </div>

    <nav class="sidebar-nav">


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-home" aria-hidden="true"></i></span>
            <span>Dashboard</span>
        </a>

        <a href="<?php echo e(route('sub-admin.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('sub-admin.*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-user-shield" aria-hidden="true"></i></span>
            <span>Sub Admin</span>
        </a>

        <a href="<?php echo e(route('customers.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('customers.index') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-users" aria-hidden="true"></i></span>
            <span>Customers</span>
        </a>

        <a href="<?php echo e(route('services.index')); ?>" class="sidebar-link <?php echo e(request()->is('services*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-broom" aria-hidden="true"></i></span>
            <span>Services</span>
        </a>

        <!-- Availability with collapse -->
        <?php $availabilityOpen = request()->routeIs('weekly-schedule.index') || request()->routeIs('weekly-schedule.edit') || request()->routeIs('holidays.index'); ?>
        <a href="#timesheets-submenu" data-toggle="collapse"
           aria-expanded="<?php echo e($availabilityOpen ? 'true' : 'false'); ?>"
           class="sidebar-link d-flex align-items-center justify-content-between <?php echo e($availabilityOpen ? '' : 'collapsed'); ?>">
            <span class="d-flex align-items-center">
                <span class="sidebar-link-icon"><i class="far fa-clock" aria-hidden="true"></i></span>
                <span>Availability</span>
            </span>
            <i class="fas fa-chevron-down ml-auto" style="font-size: 10px;" aria-hidden="true"></i>
        </a>
        <div class="collapse <?php echo e($availabilityOpen ? 'show' : ''); ?>" id="timesheets-submenu" style="padding-left: 20px;">
            <a href="<?php echo e(route('weekly-schedule.index')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('weekly-schedule.*') ? 'active' : ''); ?>"
               style="margin-left: 18px; min-height: 38px; padding: 6px 14px;">
                <span class="sidebar-link-icon" style="width: 20px; flex: 0 0 20px;"><i class="fas fa-calendar-check" aria-hidden="true"></i></span>
                <span>Weekly Schedule</span>
            </a>
            <a href="<?php echo e(route('holidays.index')); ?>"
               class="sidebar-link <?php echo e(request()->routeIs('holidays.index') ? 'active' : ''); ?>"
               style="margin-left: 18px; min-height: 38px; padding: 6px 14px;">
                <span class="sidebar-link-icon" style="width: 20px; flex: 0 0 20px;"><i class="fas fa-umbrella-beach" aria-hidden="true"></i></span>
                <span>Holidays</span>
            </a>
        </div>

        <a href="<?php echo e(route('wallets.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('wallets.*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-wallet" aria-hidden="true"></i></span>
            <span>Customer Wallets</span>
        </a>

        <a href="<?php echo e(route('bookings.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('bookings.*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="far fa-calendar-alt" aria-hidden="true"></i></span>
            <span>Bookings</span>
        </a>

        <a href="<?php echo e(route('referrals.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('referrals.*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-user-friends" aria-hidden="true"></i></span>
            <span>Referrals</span>
        </a>

        <?php if($sidebarSettings?->google_review_enabled): ?>
        <a href="<?php echo e(route('reviews.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('reviews.*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-star" aria-hidden="true"></i></span>
            <span>Review</span>
        </a>
        <?php endif; ?>

        <a href="<?php echo e(route('settings.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('settings.*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-cog" aria-hidden="true"></i></span>
            <span>Settings</span>
        </a>

        <a href="<?php echo e(route('promotions.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('promotions.*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-tags" aria-hidden="true"></i></span>
            <span>Promotional Offers</span>
        </a>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-audit-logs')): ?>
        <a href="<?php echo e(route('audit-logs.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('audit-logs.*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-history" aria-hidden="true"></i></span>
            <span>Audit Logs</span>
        </a>
        <?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer')): ?>
        <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-link">
            <span class="sidebar-link-icon"><i class="fas fa-th-large" aria-hidden="true"></i></span>
            <span>Dashboard</span>
        </a>

        <a href="<?php echo e(route('booking-service.create')); ?>" class="sidebar-link">
            <span class="sidebar-link-icon"><i class="fas fa-plus-square" aria-hidden="true"></i></span>
            <span>Book a Service</span>
        </a>

        <a href="<?php echo e(route('customer.bookings.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('customer.bookings.*') || request()->is('my-bookings*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="far fa-calendar-alt" aria-hidden="true"></i></span>
            <span>My Bookings</span>
        </a>

        <a href="<?php echo e(route('customer.wallet.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('customer.wallet.*') || request()->is('my-wallet*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-wallet" aria-hidden="true"></i></span>
            <span>Wallet</span>
        </a>

        <a href="<?php echo e(route('customer.referrals.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('customer.referrals.*') || request()->is('my-referrals*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-users" aria-hidden="true"></i></span>
            <span>Referrals</span>
        </a>

        <?php if($sidebarSettings?->google_review_enabled): ?>
        <a href="<?php echo e(route('customer.review.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('customer.review.*') || request()->is('my-review*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-star" aria-hidden="true"></i></span>
            <span>Review</span>
        </a>
        <?php endif; ?>

        <a href="<?php echo e(route('customer.profile.index')); ?>" class="sidebar-link <?php echo e(request()->routeIs('customer.profile.*') || request()->is('profile*') ? 'active' : ''); ?>">
            <span class="sidebar-link-icon"><i class="fas fa-cog" aria-hidden="true"></i></span>
            <span>Profile</span>
        </a>
        <?php endif; ?>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
        <a href="#" class="sidebar-link sidebar-link-logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <span class="sidebar-link-icon"><i class="fas fa-sign-out-alt" aria-hidden="true"></i></span>
            <span>Logout</span>
        </a>
    </nav>

    <div class="sidebar-support">
        <div class="sidebar-support-copy">
            <h6>Need help?</h6>
            <p>Our support team is available 7 days a week.</p>
        </div>

        <a href="#" class="btn support-btn">Contact Support</a>
        <i class="fas fa-headset support-icon" aria-hidden="true"></i>
    </div>
</aside>
<?php /**PATH /var/www/html/cleaning-management/resources/views/components/sidebar.blade.php ENDPATH**/ ?>