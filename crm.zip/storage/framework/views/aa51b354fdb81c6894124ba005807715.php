<header class="dashboard-header">
	    <div class="header-left">
	        <button type="button" class="sidebar-toggle" aria-label="Toggle sidebar">
	            <i class="fas fa-bars" aria-hidden="true"></i>
	        </button>

	        <div class="header-greeting">
	            <?php if(request()->is('dashboard')): ?>
	                <h1>Good Evening, <span><?php echo e(auth()->check() ? auth()->user()->first_name : 'Guest'); ?></span> &#128075;</h1>
	                <p>Here's what's happening with your account today.</p>
	            <?php endif; ?>
	        </div>
	    </div>

    <div class="header-actions">
        <button type="button"
                class="fullscreen-btn"
                id="fullscreenToggle"
                title="Fullscreen"
                aria-label="Fullscreen">
            <i class="fas fa-expand" aria-hidden="true"></i>
        </button>

        <?php
            $authUser = auth()->user();
            $unreadNotificationsCount = $authUser ? $authUser->unreadNotifications()->count() : 0;
            $headerNotifications = $authUser ? $authUser->notifications()->take(6)->get() : collect();
        ?>

        <div class="dropdown notification-dropdown">
            <button type="button"
                    class="notification-btn"
                    id="notificationDropdown"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                    aria-label="Notifications">
                <i class="far fa-bell" aria-hidden="true"></i>
                <?php if($unreadNotificationsCount > 0): ?>
                    <span class="notification-badge"><?php echo e($unreadNotificationsCount > 99 ? '99+' : $unreadNotificationsCount); ?></span>
                <?php endif; ?>
            </button>

            <div class="dropdown-menu dropdown-menu-right notification-menu" aria-labelledby="notificationDropdown">
                <div class="notification-menu-header d-flex align-items-center justify-content-between">
                    <h6 class="mb-0">Notifications</h6>
                    <?php if($unreadNotificationsCount > 0): ?>
                        <form action="<?php echo e(route('notifications.markAllRead')); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link p-0 notification-read-link" style="font-size: 13px; text-decoration: none;">Mark all as read</button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="notification-list">
                    <?php $__empty_1 = true; $__currentLoopData = $headerNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $nData = $notification->data;
                            $nTitle = $nData['title'] ?? 'Notification';
                            $nMessage = $nData['message'] ?? '';
                            $nIcon = $nData['icon'] ?? 'fas fa-bell';
                            $isUnread = is_null($notification->read_at);
                        ?>
                        <a class="dropdown-item notification-item <?php echo e($isUnread ? 'unread' : ''); ?> d-flex align-items-start" href="<?php echo e(route('notifications.read', $notification->id)); ?>">
                            <span class="notification-icon">
                                <i class="<?php echo e($nIcon); ?>" aria-hidden="true"></i>
                            </span>
                            <span class="notification-content">
                                <span class="notification-title"><?php echo e($nTitle); ?></span>
                                <span class="notification-message"><?php echo e($nMessage); ?></span>
                                <span class="notification-time"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="p-3 text-center text-muted" style="font-size: 14px;">
                            <i class="far fa-bell-slash d-block mb-2" style="font-size: 24px; opacity: 0.5;"></i>
                            No notifications yet.
                        </div>
                    <?php endif; ?>
                </div>

                <div class="notification-menu-footer">
                    <a href="<?php echo e(route('notifications.index')); ?>">See All Notifications</a>
                </div>
            </div>
        </div>

        <div class="dropdown user-profile">
            <a href="#" class="user-profile-toggle" id="userProfileDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img src="<?php echo e(auth()->check() ? auth()->user()->photo_url : 'https://i.pravatar.cc/84?img=12'); ?>" alt="User avatar" class="user-avatar">
                <span class="user-name"><?php echo e(auth()->check() ? trim(auth()->user()->first_name . ' ' . (auth()->user()->last_name ?? '')) : 'Guest'); ?></span>
                <i class="fas fa-chevron-down user-chevron" aria-hidden="true"></i>
            </a>

            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userProfileDropdown">
                <a class="dropdown-item" href="<?php echo e(route('customer.profile.index')); ?>">
                    <i class="fas fa-user-circle mr-2 text-primary"></i> Profile
                </a>
                <div class="dropdown-divider"></div>
                <form id="header-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                <a class="dropdown-item text-danger" href="#" onclick="event.preventDefault(); document.getElementById('header-logout-form').submit();">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </a>
            </div>
        </div>
    </div>
</header>
<?php /**PATH /var/www/html/cleaning-management/resources/views/components/header.blade.php ENDPATH**/ ?>