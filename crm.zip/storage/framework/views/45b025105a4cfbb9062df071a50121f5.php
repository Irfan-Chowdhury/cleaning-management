<?php echo e($slot); ?>

<?php /**PATH /var/www/html/cleaning-management/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>