<aside class="dashboard-sidebar" aria-label="Dashboard navigation">
    <div class="sidebar-logo">
        <a href="#" class="sidebar-logo-link" aria-label="Cleaning Management">
            {{-- <img src="https://placehold.co/340x96/0f766e/ffffff?text=Sparkle+Care" alt="Cleaning Management logo"> --}}
            <img id="sidebar-company-logo" src="{{ $sidebarSettings?->company_logo_url ?? asset('public/assets/images/company_logo/brand_logo.png') }}" alt="Cleaning Management logo">
        </a>

        <button type="button" class="sidebar-close" aria-label="Close sidebar">
            <i class="fas fa-times" aria-hidden="true"></i>
        </button>
    </div>

    <nav class="sidebar-nav">


        @can('admin')
        <a href="{{ route('admin.dashboard') }}" class="sidebar-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-home" aria-hidden="true"></i></span>
            <span>Dashboard</span>
        </a>

        <a href="{{ route('sub-admin.index') }}" class="sidebar-link {{ request()->routeIs('sub-admin.*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-user-shield" aria-hidden="true"></i></span>
            <span>Sub Admin</span>
        </a>

        <a href="{{ route('customers.index') }}" class="sidebar-link {{ request()->routeIs('customers.index') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-users" aria-hidden="true"></i></span>
            <span>Customers</span>
        </a>

        <a href="{{ route('services.index') }}" class="sidebar-link {{ request()->is('services*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-broom" aria-hidden="true"></i></span>
            <span>Services</span>
        </a>

        <!-- Availability with collapse -->
        @php $availabilityOpen = request()->routeIs('weekly-schedule.index') || request()->routeIs('weekly-schedule.edit') || request()->routeIs('holidays.index'); @endphp
        <a href="#timesheets-submenu" data-toggle="collapse"
           aria-expanded="{{ $availabilityOpen ? 'true' : 'false' }}"
           class="sidebar-link d-flex align-items-center justify-content-between {{ $availabilityOpen ? '' : 'collapsed' }}">
            <span class="d-flex align-items-center">
                <span class="sidebar-link-icon"><i class="far fa-clock" aria-hidden="true"></i></span>
                <span>Availability</span>
            </span>
            <i class="fas fa-chevron-down ml-auto" style="font-size: 10px;" aria-hidden="true"></i>
        </a>
        <div class="collapse {{ $availabilityOpen ? 'show' : '' }}" id="timesheets-submenu" style="padding-left: 20px;">
            <a href="{{ route('weekly-schedule.index') }}"
               class="sidebar-link {{ request()->routeIs('weekly-schedule.*') ? 'active' : '' }}"
               style="margin-left: 18px; min-height: 38px; padding: 6px 14px;">
                <span class="sidebar-link-icon" style="width: 20px; flex: 0 0 20px;"><i class="fas fa-calendar-check" aria-hidden="true"></i></span>
                <span>Weekly Schedule</span>
            </a>
            <a href="{{ route('holidays.index') }}"
               class="sidebar-link {{ request()->routeIs('holidays.index') ? 'active' : '' }}"
               style="margin-left: 18px; min-height: 38px; padding: 6px 14px;">
                <span class="sidebar-link-icon" style="width: 20px; flex: 0 0 20px;"><i class="fas fa-umbrella-beach" aria-hidden="true"></i></span>
                <span>Holidays</span>
            </a>
        </div>

        <a href="{{ route('wallets.index') }}" class="sidebar-link {{ request()->routeIs('wallets.*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-wallet" aria-hidden="true"></i></span>
            <span>Customer Wallets</span>
        </a>

        <a href="{{ route('bookings.index') }}" class="sidebar-link {{ request()->routeIs('bookings.*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="far fa-calendar-alt" aria-hidden="true"></i></span>
            <span>Bookings</span>
        </a>

        <a href="{{ route('referrals.index') }}" class="sidebar-link {{ request()->routeIs('referrals.*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-user-friends" aria-hidden="true"></i></span>
            <span>Referrals</span>
        </a>

        @if($sidebarSettings?->google_review_enabled)
        <a href="{{ route('reviews.index') }}" class="sidebar-link {{ request()->routeIs('reviews.*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-star" aria-hidden="true"></i></span>
            <span>Review</span>
        </a>
        @endif

        <a href="{{ route('settings.index') }}" class="sidebar-link {{ request()->routeIs('settings.*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-cog" aria-hidden="true"></i></span>
            <span>Settings</span>
        </a>

        <a href="{{ route('promotions.index') }}" class="sidebar-link {{ request()->routeIs('promotions.*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-tags" aria-hidden="true"></i></span>
            <span>Promotional Offers</span>
        </a>

        @can('view-audit-logs')
        <a href="{{ route('audit-logs.index') }}" class="sidebar-link {{ request()->routeIs('audit-logs.*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-history" aria-hidden="true"></i></span>
            <span>Audit Logs</span>
        </a>
        @endcan
        @endcan

        @can('customer')
        <a href="{{ route('dashboard') }}" class="sidebar-link">
            <span class="sidebar-link-icon"><i class="fas fa-th-large" aria-hidden="true"></i></span>
            <span>Dashboard</span>
        </a>

        <a href="{{ route('booking-service.create') }}" class="sidebar-link">
            <span class="sidebar-link-icon"><i class="fas fa-plus-square" aria-hidden="true"></i></span>
            <span>Book a Service</span>
        </a>

        <a href="{{ route('customer.bookings.index') }}" class="sidebar-link {{ request()->routeIs('customer.bookings.*') || request()->is('my-bookings*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="far fa-calendar-alt" aria-hidden="true"></i></span>
            <span>My Bookings</span>
        </a>

        <a href="{{ route('customer.wallet.index') }}" class="sidebar-link {{ request()->routeIs('customer.wallet.*') || request()->is('my-wallet*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-wallet" aria-hidden="true"></i></span>
            <span>Wallet</span>
        </a>

        <a href="{{ route('customer.referrals.index') }}" class="sidebar-link {{ request()->routeIs('customer.referrals.*') || request()->is('my-referrals*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-users" aria-hidden="true"></i></span>
            <span>Referrals</span>
        </a>

        @if($sidebarSettings?->google_review_enabled)
        <a href="{{ route('customer.review.index') }}" class="sidebar-link {{ request()->routeIs('customer.review.*') || request()->is('my-review*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-star" aria-hidden="true"></i></span>
            <span>Review</span>
        </a>
        @endif

        <a href="{{ route('customer.profile.index') }}" class="sidebar-link {{ request()->routeIs('customer.profile.*') || request()->is('profile*') ? 'active' : '' }}">
            <span class="sidebar-link-icon"><i class="fas fa-cog" aria-hidden="true"></i></span>
            <span>Profile</span>
        </a>
        @endcan

        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
        </form>
        <a href="#" class="sidebar-link sidebar-link-logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <span class="sidebar-link-icon"><i class="fas fa-sign-out-alt" aria-hidden="true"></i></span>
            <span>Logout</span>
        </a>
    </nav>

    <div class="sidebar-support">
        <div class="sidebar-support-copy">
            <h6>Need help?</h6>
            <p>Our support team is available 7 days a week.</p>
        </div>

        <a href="#" class="btn support-btn">Contact Support</a>
        <i class="fas fa-headset support-icon" aria-hidden="true"></i>
    </div>
</aside>
