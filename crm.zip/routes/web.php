<?php

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\BookingServiceController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\SubAdminController;
use App\Http\Controllers\WeeklyScheduleController;
use App\Http\Controllers\HolidayController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\ReferralController;
use App\Http\Controllers\PromotionController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\AuditLogController;
use App\Http\Controllers\Admin\GoogleReviewController as AdminGoogleReviewController;
use App\Http\Middleware\EnsureGoogleReviewEnabled;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\VerificationController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\Customer\ProfileController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use Illuminate\Support\Facades\File;
use App\Models\Setting;

Route::get('/', function () {
    if (! Auth::check()) {
        return redirect()->route('login');
    }

    return (int) Auth::user()->role === 1
        ? redirect()->route('admin.dashboard')
        : redirect()->route('dashboard');
});

Route::middleware('guest')->group(function () {
    Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register', [RegisterController::class, 'register']);

    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);

    Route::post('/forgot-password', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
    Route::get('/reset-password/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');
    Route::post('/reset-password', [ResetPasswordController::class, 'reset'])->name('password.update');
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Email Verification Routes
Route::middleware('auth')->group(function () {
    Route::get('/email/verify', [VerificationController::class, 'notice'])->name('verification.notice');
    Route::get('/email/verify/{id}/{hash}', [VerificationController::class, 'verify'])
        ->middleware('signed')
        ->name('verification.verify');
    Route::post('/email/verification-notification', [VerificationController::class, 'resend'])
        ->middleware('throttle:6,1')
        ->name('verification.send');
});

// System Notification Routes (Accessible by all authenticated users)
Route::middleware('auth')->group(function () {
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::get('/notifications/{id}/read', [NotificationController::class, 'read'])->name('notifications.read');
    Route::post('/notifications/mark-all-read', [NotificationController::class, 'markAllRead'])->name('notifications.markAllRead');
    Route::delete('/notifications/{id}', [NotificationController::class, 'destroy'])->name('notifications.destroy');
});

// User Profile Routes (Accessible by all authenticated users: Admin & Customer)
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'index'])->name('customer.profile.index');
    Route::post('/profile', [ProfileController::class, 'update'])->name('customer.profile.update');
});

// Booking Wizard Routes (Accessible by both Admin & Customer)
Route::middleware('auth')->prefix('booking-service')->group(function () {
    Route::get('/create', [BookingServiceController::class, 'create'])->name('booking-service.create');
    Route::post('/step-1', [BookingServiceController::class, 'storeStep1'])->name('booking-service.store-step-1');
    Route::get('/questionnaire/{service}', [BookingServiceController::class, 'questionnaire'])->name('booking-service.questionnaire');
    Route::get('/date-time', [BookingServiceController::class, 'dateTime'])->name('booking-service.date-time');
    Route::post('/step-2', [BookingServiceController::class, 'storeStep2'])->name('booking-service.store-step-2');
    Route::get('/slots-for-date', [BookingServiceController::class, 'slotsForDate'])->name('booking-service.slots-for-date');
    Route::get('/your-details', [BookingServiceController::class, 'yourDetails'])->name('booking-service.your-details');
    Route::post('/step-3', [BookingServiceController::class, 'storeStep3'])->name('booking-service.store-step-3');
    Route::get('/review-confirm', [BookingServiceController::class, 'step4ReviewConfirm'])->name('booking-service.review-confirm');
    Route::post('/confirm', [BookingServiceController::class, 'confirmBooking'])->name('booking-service.confirm');
    Route::post('/apply-promo', [BookingServiceController::class, 'applyPromo'])->name('booking-service.apply-promo');
    Route::post('/remove-promo', [BookingServiceController::class, 'removePromo'])->name('booking-service.remove-promo');
});

// Admin Protected Routes
Route::middleware(['auth', 'can:admin'])->group(function () {
    Route::get('/admin-dashboard', [AdminDashboardController::class, 'index'])->name('admin.dashboard');

    Route::get('/sub-admins', [SubAdminController::class, 'index'])->name('sub-admin.index');
    Route::post('/sub-admins', [SubAdminController::class, 'store'])->name('sub-admin.store');
    Route::put('/sub-admins/{sub_admin}', [SubAdminController::class, 'update'])->name('sub-admin.update');
    Route::delete('/sub-admins/{sub_admin}', [SubAdminController::class, 'destroy'])->name('sub-admin.destroy');

    Route::get('/customers', [CustomerController::class, 'index'])->name('customers.index');
    Route::post('/customers', [CustomerController::class, 'store'])->name('customers.store');
    Route::get('/customers/{customer}', [CustomerController::class, 'show'])->name('customers.show');
    Route::put('/customers/{customer}', [CustomerController::class, 'update'])->name('customers.update');
    Route::delete('/customers/{customer}', [CustomerController::class, 'destroy'])->name('customers.destroy');

    Route::get('/weekly-schedule', [WeeklyScheduleController::class, 'index'])->name('weekly-schedule.index');
    Route::get('/weekly-schedule/{day}/edit', [WeeklyScheduleController::class, 'edit'])
        ->name('weekly-schedule.edit')
        ->where('day', 'monday|tuesday|wednesday|thursday|friday|saturday|sunday');
    Route::put('/weekly-schedule/{day}', [WeeklyScheduleController::class, 'update'])
        ->name('weekly-schedule.update')
        ->where('day', 'monday|tuesday|wednesday|thursday|friday|saturday|sunday');

    Route::get('/holidays',              [HolidayController::class, 'index'])->name('holidays.index');
    Route::post('/holidays',             [HolidayController::class, 'store'])->name('holidays.store');
    Route::put('/holidays/{holiday}',    [HolidayController::class, 'update'])->name('holidays.update');
    Route::delete('/holidays/{holiday}', [HolidayController::class, 'destroy'])->name('holidays.destroy');

    Route::resource('services', ServiceController::class);

    Route::get('/wallets', [WalletController::class, 'index'])->name('wallets.index');
    Route::get('/wallets/{id}', [WalletController::class, 'show'])->name('wallets.show');

    Route::get('/bookings', [BookingController::class, 'index'])->name('bookings.index');
    Route::get('/bookings/{id}', [BookingController::class, 'show'])->name('bookings.show');
    Route::get('/bookings/{id}/edit', [BookingController::class, 'edit'])->name('bookings.edit');
    Route::put('/bookings/{id}', [BookingController::class, 'update'])->name('bookings.update');

    Route::get('/referrals', [ReferralController::class, 'index'])->name('referrals.index');

    Route::get('/promotions', [PromotionController::class, 'index'])->name('promotions.index');
    Route::post('/promotions', [PromotionController::class, 'store'])->name('promotions.store');
    Route::put('/promotions/{promotion}', [PromotionController::class, 'update'])->name('promotions.update');
    Route::delete('/promotions/{promotion}', [PromotionController::class, 'destroy'])->name('promotions.destroy');

    Route::get('/settings', [SettingController::class, 'index'])->name('settings.index');
    Route::post('/settings', [SettingController::class, 'update'])->name('settings.update');

    // Audit Logs (with explicit view-audit-logs Gate)
    Route::get('/audit-logs', [AuditLogController::class, 'index'])
        ->middleware('can:view-audit-logs')
        ->name('audit-logs.index');
    Route::get('/audit-logs/{auditLog}', [AuditLogController::class, 'show'])
        ->middleware('can:view-audit-logs')
        ->name('audit-logs.show');

    // Google Review Reward Admin Routes
    Route::middleware(EnsureGoogleReviewEnabled::class)->group(function () {
        Route::get('/reviews', [AdminGoogleReviewController::class, 'index'])->name('reviews.index');
        Route::get('/reviews/data', [AdminGoogleReviewController::class, 'data'])->name('reviews.data');
        Route::get('/reviews/{review}/edit', [AdminGoogleReviewController::class, 'edit'])->name('reviews.edit');
        Route::post('/reviews/{review}/approve', [AdminGoogleReviewController::class, 'approve'])->name('reviews.approve');
        Route::post('/reviews/{review}/cancel', [AdminGoogleReviewController::class, 'cancel'])->name('reviews.cancel');
        Route::delete('/reviews/{review}', [AdminGoogleReviewController::class, 'destroy'])->name('reviews.destroy');
    });
});

require __DIR__.'/customer.php';

// Utility routes — restricted to authenticated admins only
Route::middleware(['auth', 'can:admin'])->group(function () {
    Route::get('/clear-cache', function () {
        Artisan::call('view:clear');
        Artisan::call('cache:clear');
        return 'Cache cleared successfully!';
    });

    Route::get('/run-migrate', function () {
        Artisan::call('migrate', ['--force' => true]);
        return nl2br(Artisan::output());
    });

    Route::get('/run-seeder/{class}', function (string $class) {
        // Only allow simple class names (no namespace injection via backslash)
        $seederClass = 'Database\\Seeders\\' . $class;

        if (! class_exists($seederClass)) {
            abort(404, 'Seeder class not found.');
        }

        Artisan::call('db:seed', [
            '--class' => $seederClass,
            '--force' => true,
        ]);

        return nl2br(Artisan::output());
    })->where('class', '[A-Za-z0-9_]+');

    Route::get('/documentation', function () {
        $content = File::get(public_path() . '/documentation/index.html');
        try {
            $setting = Setting::latest()->first();
            $logoUrl = $setting?->company_logo_url;
        } catch (\Throwable $e) {
            $logoUrl = null;
        }

        $logoUrl = $logoUrl ?? asset('public/assets/images/company_logo/brand_logo.png');

        $content = preg_replace(
            '/<img\s+id="doc-logo"\s+src="[^"]*"/i',
            '<img id="doc-logo" src="' . e($logoUrl) . '"',
            $content
        );

        return response($content);
    });
});
